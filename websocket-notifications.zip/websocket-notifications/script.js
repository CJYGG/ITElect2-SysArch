const ws = new WebSocket('ws://localhost:3000');

ws.onopen = () => console.log('Connected to server');
ws.onmessage = (event) => {
    const notificationList = document.getElementById('notifications');
    const li = document.createElement('li');
    li.textContent = event.data;
    notificationList.appendChild(li);
};

function sendMessage() {
    const input = document.getElementById('message');
    if (input.value.trim()) {
        ws.send(input.value);
        input.value = '';
    }
}