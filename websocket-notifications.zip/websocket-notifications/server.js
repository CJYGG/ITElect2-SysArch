// server.js (Backend - Node.js with Express & WebSocket)
const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });


app.use(express.static('public')); // Serve frontend files

wss.on('connection', (ws) => {
    console.log('New client connected');

    ws.on('message', (message) => {
        console.log(`Received: ${message}`);
        const textMessage = message.toString(); // Ensure message is sent as text
    
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(textMessage); // Send as plain text
            }
        });
    });       

    ws.on('close', () => console.log('Client disconnected'));
});

server.listen(3000, () => console.log('Server running on http://localhost:3000'));
