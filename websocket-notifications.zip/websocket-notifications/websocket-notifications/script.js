const ws = new WebSocket('ws://localhost:3000');

ws.onopen = () => console.log('Connected to server');
ws.onmessage = async (event) => {
    const notificationList = document.getElementById('notifications');
    const li = document.createElement('li');

    if (event.data instanceof Blob) {
        const text = await event.data.text(); // Convert Blob to text
        li.textContent = text;
    } else {
        li.textContent = event.data;
    }

    notificationList.appendChild(li);
};

function sendMessage() {
    const input = document.getElementById('message');
    if (input.value.trim()) {
        ws.send(input.value);
        input.value = '';
    }
}